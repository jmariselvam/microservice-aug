package org.cap.demo.controller;

import org.cap.demo.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@RequestMapping("/logout")
	public String logout() {
		return "login";
	}
	
	@RequestMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}

	@RequestMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@RequestMapping("/getEmployees")
	public ModelAndView getEmployees() {
		ModelAndView modelAndView=new ModelAndView("getEmployees");
		return modelAndView;
	}
	@GetMapping("/addNewEmployee")
	public ModelAndView getAddEmployeePage() {
		return new ModelAndView("addEmployee","emp",new Employee());
	}
	
	@PostMapping("/addNewEmployee")
	public ModelAndView addEmployee(@ModelAttribute("emp")Employee emp) {
		System.out.println(emp);
		ModelAndView modelAndView=new ModelAndView("getEmployees");
		
				return modelAndView;
	}
	
}
