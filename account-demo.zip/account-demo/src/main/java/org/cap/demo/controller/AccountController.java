package org.cap.demo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.cap.demo.model.Account;
import org.cap.demo.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class AccountController {

	@Autowired
	private IAccountService accountService;
	@GetMapping("/customer/{strStartsWith}")
	public ResponseEntity<List<String>> getAllCustomer(
			@PathVariable("strStartsWith")String strStartsWith
			){
		
		List<String> customers= accountService.getAllCustomerStartsWith(strStartsWith);
		if(customers==null || customers.isEmpty() )
			return new ResponseEntity("Sorry! No Customers Available in Db!",
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<String>>(customers,HttpStatus.OK);
	}
	
	
	
	
	@GetMapping("/findAcc/{balance}/{openDate}")
	public ResponseEntity<List<Account>> getAllAccountdetails(
			@PathVariable("balance")double balance,
			@PathVariable("openDate")String date){
		
		LocalDate date2=LocalDate.parse(date, 
				DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
		
		List<Account> accounts= accountService.findByBalanceAndOpeningDate(balance, date2);
		if(accounts==null || accounts.isEmpty() )
			return new ResponseEntity("Sorry! No Accounts Available in Db!",
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//update balance and accounttype
	@PatchMapping("/account")
	public ResponseEntity<Account> UpdateAccount(
			@RequestBody Account account){
		Account account1= accountService.updateAccount(account);
		
		if(account1==null  )
			return new ResponseEntity("Sorry! Updation error!",
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<Account>(account1,HttpStatus.OK);
		
	}
	
	
	
	@PatchMapping("/deposit/{accountNo}/{amount}")
	public ResponseEntity<Account> balanceUpdateAccount(
			@PathVariable("amount")double amount,
			@PathVariable("accountNo")Long accountNo){
		Account account= accountService.updateBalance(accountNo,amount);
		
		if(account==null  )
			return new ResponseEntity("Sorry! Updation error!",
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<Account>(account,HttpStatus.OK);
		
	}
	
	
	@DeleteMapping("/account/{accountNo}")
	public ResponseEntity<List<Account>> deleteAccount(@PathVariable("accountNo")Long accountNo){
		List<Account> accounts= accountService.deleteAccount(accountNo);
		
		if(accounts==null || accounts.isEmpty() )
			return new ResponseEntity("Sorry! No Accounts Available in Db!",
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
		
	}
	
	
	
	@GetMapping("/account/{accountNo}")
	public ResponseEntity<Account> findAccount(@PathVariable("accountNo")Long accountNo){
		Account account= accountService.findAccount(accountNo);
		
		if(account==null )
			return new ResponseEntity("Sorry! No Such Account ID exists in Db!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Account>(account,HttpStatus.OK);
		
		
	}
	

	
	
	
	
	
	@GetMapping("/account")
	public ResponseEntity<List<Account>> getAllAccounts(){
		List<Account> accounts= accountService.getAllAccounts();
		
		if(accounts==null || accounts.isEmpty() )
			return new ResponseEntity("Sorry! No Accounts Available in Db!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
		
		
	}
	
	
	@PostMapping("/account")
	public ResponseEntity<List<Account>> saveAccount(
			@RequestBody Account account){
		
		List<Account> accounts=accountService.saveAccount(account);
		
		if(accounts==null || accounts.isEmpty() )
			return new ResponseEntity("Sorry! No Accounts Available in Db!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts,HttpStatus.OK);
		
	}
	
}
