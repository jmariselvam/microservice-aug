package org.cap.demo.service;

import java.time.LocalDate;
import java.util.List;

import org.cap.demo.model.Account;
import org.springframework.data.repository.query.Param;

public interface IAccountService {

	public List<Account> saveAccount(Account account);

	public List<Account> getAllAccounts();

	public Account findAccount(Long accountNo);

	public List<Account> deleteAccount(Long accountNo);

	public Account updateBalance(Long accountNo, double amount);

	public Account updateAccount(Account account);
	public List<Account> findByBalanceAndOpeningDate(double balance,LocalDate openingDate);
	
	public List<String> getAllCustomerStartsWith(String nameStartsWith);
}
