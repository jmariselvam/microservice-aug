package org.cap.demo.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.dao.IAccountDao;
import org.cap.demo.dao.ICustomerDao;
import org.cap.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
@Transactional
public class AccountServiceImpl implements IAccountService{
	
	@Autowired
	private IAccountDao accountDao;
	
	@Autowired
	private ICustomerDao customerDao;

	@Override
	public List<Account> saveAccount(Account account) {
		customerDao.save(account.getCustomer());
		accountDao.save(account);
		return accountDao.findAll();
	}

	@Override
	public List<Account> getAllAccounts() {
		
		return accountDao.findAll();
	}

	@Override
	public Account findAccount(Long accountNo) {
		
		return accountDao.getOne(accountNo);
	}

	@Override
	public List<Account> deleteAccount(Long accountNo) {
		Account  account= findAccount(accountNo);
		if(account!=null)
				accountDao.delete(account);
		return getAllAccounts();
	}

	@Override
	public Account updateBalance(Long accountNo, double amount) {
		Account account=findAccount(accountNo);
		if(account!=null)
			account.setBalance(account.getBalance()+amount);
		return account;
	}

	@Override
	public Account updateAccount(Account account) {
		Account account1=findAccount(account.getAccountId());
		if(account!=null) {
			account1.setAccountType(account.getAccountType());
			account1.setBalance(account.getBalance());
		}
		return account1;
	}

	@Override
	public List<Account> findByBalanceAndOpeningDate(double balance, LocalDate openingDate) {
		
		return accountDao.findByBalanceAndOpeningDate(balance, openingDate);
	}

	@Override
	public List<String> getAllCustomerStartsWith(String nameStartsWith) {
		
		return customerDao.getAllCustomerStartsWith(nameStartsWith);
	}

}
