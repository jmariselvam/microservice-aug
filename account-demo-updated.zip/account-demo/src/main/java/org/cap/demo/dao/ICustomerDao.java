package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("customerDao")
public interface ICustomerDao extends JpaRepository<Customer, Integer>{

	@Query("select customerName from Customer where customerName like :nameStartsWith%")
	public List<String> getAllCustomerStartsWith(@Param("nameStartsWith")String nameStartsWith);
	
}
