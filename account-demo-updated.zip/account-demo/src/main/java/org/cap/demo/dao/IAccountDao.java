package org.cap.demo.dao;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("accountDao")
public interface IAccountDao extends JpaRepository<Account, Long>{
	
	public List<Account> findByBalanceAndOpeningDate(double balance,LocalDate openingDate);

}
