package org.cap.demo.model;

import java.time.LocalDate;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties({"hibernateLazyInitializer"})
public class Account {
	private long accountId;
	@JsonFormat(pattern = "dd-MMM-yyyy")
	private LocalDate openingDate;
	private String accountType;
	private double balance;
	
	
	private Customer customer;

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	

	public Account(long accountId, String accountType, double balance) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.balance = balance;
	}

	public Account(long accountId, LocalDate openingDate, String accountType, double balance, Customer customer) {
		super();
		this.accountId = accountId;
		this.openingDate = openingDate;
		this.accountType = accountType;
		this.balance = balance;
		this.customer = customer;
	}

	public Account() {
		super();
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", openingDate=" + openingDate + ", accountType=" + accountType
				+ ", balance=" + balance + ", customer=" + customer + "]";
	}
	
	

}
