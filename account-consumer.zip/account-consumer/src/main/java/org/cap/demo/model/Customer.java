package org.cap.demo.model;

import java.util.ArrayList;
import java.util.List;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class Customer {
	
	private int customerId;
	private String customerName;
	private String addressLine;
	
	
	@JsonIgnore
	private List<Account> accounts=new ArrayList<>();
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", addressLine=" + addressLine
				+ ", accounts=" + accounts + "]";
	}
	public Customer(int customerId, String customerName, String addressLine, List<Account> accounts) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.addressLine = addressLine;
		this.accounts = accounts;
	}
	public Customer() {
		super();
	}
	
	

}
