package org.cap.demo.controller;

import org.cap.demo.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/consumer")
public class ConsumerController {
	
	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/findAcc/{accNo}")
	public ResponseEntity<Account> searchAccountDetails(
			@PathVariable("accNo")Long accNo){
		
		
		//RestTemplate restTemplate=new RestTemplate();
		
		//expose the URL
		//String url="http://localhost:8082/api/v1/account/"+accNo;
		
		String url="http://ACCOUNT-PRODUCER/api/v1/account/"+accNo;
		
		ResponseEntity<Account> response=restTemplate.getForEntity(url, Account.class);
		
		return response;
	}
	
	@LoadBalanced
	@Bean
	private RestTemplate getRestTeamplate() {
		return new RestTemplate();
	}
	
}
